# Multi-event Flood Severity Index (FSI)

Python implementation of the Flood Severity Index and its robustness diagnostics
(Module 4 of the Multi-Event Driver Attribution Framework, MEDAF), as used in:

> Abitha A. and Sridharan B. (2026). *[Manuscript title]*. Environmental Modelling & Software (submitted).

The script works for **any number of flood events N ≥ 2**. In the manuscript, N = 8
(1976, 1985, 1991, 1996, 2005, 2008, 2015, 2023), using the maximum flood-depth maps of
the combined fluvial–pluvial reference simulations (S4).

## Method

For each grid cell *i* and event *j*, the maximum flood depth *d<sub>ij</sub>* is converted
to a severity score *S<sub>ij</sub>*:

| Max depth (m) | ≤ 0.1 | 0.1–0.25 | 0.25–0.5 | 0.5–1 | 1–2 | 2–3 | > 3 |
|---|---|---|---|---|---|---|---|
| Score | 0 | 1 | 2 | 3 | 4 | 5 | 6 |

Each depth class includes its upper bound. The FSI is

  FSI<sub>i</sub> = Σ<sub>j=1..N</sub> S<sub>ij</sub> / (S<sub>max</sub> · N),  with S<sub>max</sub> = 6,

which is bounded between 0 and 1 for any N. The FSI is evaluated for all cells inundated
above 0.1 m in at least one event, excluding cells whose centre lies within the optional
mask polygon (e.g. the permanent river channel and sea). Classes: very low [0, 0.2),
low [0.2, 0.4), moderate [0.4, 0.6), high [0.6, 0.8), very high [0.8, 1.0]; each class
includes its lower bound.

**Buildings (optional).** Each footprint is assigned to the highest FSI class of the grid
cells it intersects, so every building is counted once.

**Robustness diagnostics (optional).**
1. *Leave-one-event-out*: the FSI is recomputed N times with one event excluded
   (N − 1 in the equation); the high + very high zone (FSI ≥ 0.6) is compared with that
   from all events using the Jaccard similarity (intersection / union), and the
   percentage of cells changing class is recorded.
2. *Frequency-only index*: fraction of events with depth > 0.1 m; Spearman ρ with the FSI.
3. *Depth thresholds*: class boundaries 0.25–3 m are shifted by −25 % and +25 %
   (0.1 m threshold kept) and the change in the high + very high area is reported.

## Installation

Python ≥ 3.9.

```
pip install -r requirements.txt
```

## Usage

```
python fsi.py --events <grids...> [--mask river.shp] [--buildings buildings.shp]
              [--crs EPSG:xxxx] [--robustness] [--map] [--format tif|asc] [--out DIR]
```

* `--events`: one maximum-depth grid per event, as file paths, glob patterns or
  `name=path` pairs. Any GDAL-readable raster (GeoTIFF, ESRI ASCII grid `.asc`/`.txt`).
  All grids must share the same extent and resolution. The event name is taken from the
  first four-digit year in the file name, unless given as `name=path`.
* `--mask`: polygon shapefile of areas excluded from the FSI.
* `--buildings`: polygon shapefile of building footprints.
* `--crs`: CRS of the depth grids if the files do not store it (ESRI ASCII grids exported
  from HEC-RAS usually do not). Mask and buildings must be in the same CRS.
* `--depth-edges`, `--class-breaks`, `--threshold-shift`: change the default scheme.

### Reproducing the manuscript (N = 8)

```
python fsi.py \
  --events "data/*_ASCII/pluvial_*.txt" \
  --mask data/River_ocean.shp \
  --buildings data/Building_polygon.shp \
  --crs EPSG:32644 --robustness --map --out results
```

Expected output (Tables 10 and 11 of the manuscript):

```
  Very low   0-0.2       26.38 km2   48.5 %  buildings  21,660
  Low        0.2-0.4     14.79 km2   27.2 %  buildings  11,143
  Moderate   0.4-0.6      6.32 km2   11.6 %  buildings   3,788
  High       0.6-0.8      4.26 km2    7.8 %  buildings   1,947
  Very high  0.8-1        2.67 km2    4.9 %  buildings   1,140
  Total      -           54.42 km2  100.0 %  buildings  39,678

  Jaccard (min / mean / max): 0.87 / 0.93 / 1.00
  Cells changing class (mean / max): 5.8 / 10.9 %
  Most influential event: 1991 (Jaccard), 2015 (class change)
  Spearman rho FSI vs frequency: 0.80
  Depth thresholds -/+25%: +33.5 / -22.9 % (high + very high area)
```

### Other numbers of events

```
python fsi.py --events ev1.tif ev2.tif ev3.tif ev4.tif --mask river.shp --robustness --out results_n4
python fsi.py --events "flood_A=a.asc" "flood_B=b.asc" "flood_C=c.asc" --out results_n3
```

## Outputs

| File | Content |
|---|---|
| `FSI_values.tif` | FSI (0–1); −9999 outside the evaluated area |
| `FSI_classes.tif` | 1 very low … 5 very high; 0 outside |
| `events_inundated.tif` | number of events with depth > 0.1 m |
| `fsi_class_summary.csv` | area (km², %) and buildings per class |
| `event_inundated_area.csv` | inundated area per event (depth > 0.1 m, mask excluded) |
| `robustness_leave_one_out.csv` | Jaccard, class change and area change per excluded event |
| `robustness_summary.json` | Table 11 values |
| `FSI_map.png` | map of the FSI classes |
| `run_log.json` | inputs, parameters and software versions |

## Tests

```
python test_fsi.py
```

## License

MIT (see `LICENSE`).
