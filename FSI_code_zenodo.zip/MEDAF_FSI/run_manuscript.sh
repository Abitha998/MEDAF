#!/usr/bin/env bash
# Reproduces Tables 10 and 11 and Figure 14 data of the manuscript (N = 8 events, S4 runs).
python fsi.py \
  --events "data/*_ASCII/pluvial_*.txt" \
  --mask data/River_ocean.shp \
  --buildings data/Building_polygon.shp \
  --crs EPSG:32644 --robustness --map --out results
