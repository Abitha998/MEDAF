#!/usr/bin/env python3
"""
Multi-event Flood Severity Index (FSI) with robustness diagnostics.

Module 4 of the Multi-Event Driver Attribution Framework (MEDAF).

For N flood events, the maximum flood depth d(i,j) of each grid cell i in
event j is converted to a severity score S(i,j) using depth classes
(default: Table 3 of the manuscript), and the FSI is

    FSI(i) = sum_j S(i,j) / (S_max * N)

The FSI is evaluated for all cells inundated above the no-flood threshold
(default 0.1 m) in at least one event, optionally excluding the area covered
by a mask polygon (e.g. the permanent river channel and sea). The FSI is
classified into five equal-interval classes (very low ... very high).

Optional outputs:
  * building counts per FSI class (each footprint assigned to the highest
    class of the grid cells it intersects),
  * robustness diagnostics: leave-one-event-out Jaccard similarity of the
    high + very high zone and cells changing class, Spearman correlation with
    a frequency-only index, and sensitivity to shifting the depth-class
    boundaries,
  * a PNG map of the FSI classes.

Any number of events (N >= 2) is supported. Input depth grids must share the
same grid (extent, resolution, rows and columns). Any GDAL-readable raster
(GeoTIFF, ESRI ASCII grid .asc/.txt, ...) can be used.

Example (reproduces the manuscript, N = 8):
    python fsi.py \
        --events "data/*/pluvial_*.txt" \
        --mask data/River_ocean.shp \
        --buildings data/Building_polygon.shp \
        --crs EPSG:32644 --robustness --map --out results

License: MIT (see LICENSE).
"""
from __future__ import annotations

import argparse
import csv
import glob
import json
import os
import platform
import re
import sys
import time
from dataclasses import dataclass, field

import numpy as np

__version__ = "1.0.0"

DEFAULT_EDGES = [0.1, 0.25, 0.5, 1.0, 2.0, 3.0]      # Table 3 (m); <= 0.1 m -> score 0
DEFAULT_CLASS_BREAKS = [0.2, 0.4, 0.6, 0.8]
CLASS_NAMES = ["Very low", "Low", "Moderate", "High", "Very high"]
CLASS_COLOURS = ["#1a7a1a", "#9ACD32", "#FFD700", "#FF8C00", "#E31A1C"]
HIGH_CLASS_INDEX = 3                                  # high + very high = FSI >= 0.6


# ----------------------------------------------------------------------------
# Core computations (pure NumPy, no I/O) - can be imported and reused
# ----------------------------------------------------------------------------
def severity_scores(depth: np.ndarray, edges=DEFAULT_EDGES) -> np.ndarray:
    """Severity score for each depth value.

    Score k is assigned to edges[k-1] < d <= edges[k]; d <= edges[0] -> 0;
    d > edges[-1] -> len(edges). NaN (dry / NoData) -> 0.
    """
    d = np.nan_to_num(depth, nan=0.0)
    return np.searchsorted(np.asarray(edges, dtype=float), d, side="left").astype(np.uint8)


def compute_fsi(scores: np.ndarray, s_max: int) -> np.ndarray:
    """FSI = sum_j S_ij / (S_max * N) for a (N, ...) stack of scores."""
    n = scores.shape[0]
    return scores.sum(axis=0, dtype=np.int32) / float(s_max * n)


def classify(fsi: np.ndarray, breaks=DEFAULT_CLASS_BREAKS) -> np.ndarray:
    """Class index 0..len(breaks); each class includes its lower bound."""
    return np.digitize(fsi, breaks, right=False).astype(np.int8)


def jaccard(a: np.ndarray, b: np.ndarray, w: np.ndarray | None = None) -> float:
    w = np.ones(a.shape) if w is None else w
    union = w[a | b].sum()
    return float(w[a & b].sum() / union) if union > 0 else float("nan")


# ----------------------------------------------------------------------------
# I/O helpers
# ----------------------------------------------------------------------------
@dataclass
class Grid:
    transform: object
    crs: object
    shape: tuple
    cell_area: float
    nodata: float | None = None
    profile: dict = field(default_factory=dict)


def expand_events(items: list[str]) -> list[tuple[str, str]]:
    """Accept 'name=path' pairs, file paths or glob patterns."""
    out = []
    for item in items:
        if "=" in item and not os.path.exists(item):
            name, path = item.split("=", 1)
            out.append((name, path))
            continue
        paths = sorted(glob.glob(item)) or [item]
        for p in paths:
            base = os.path.splitext(os.path.basename(p))[0]
            m = re.search(r"(1[89]\d{2}|20\d{2})", base)     # use the year if present
            out.append((m.group(1) if m else base, p))
    names = [n for n, _ in out]
    if len(set(names)) != len(names):
        raise SystemExit(f"Duplicate event names: {names}. Use name=path to label events.")
    return out


def read_depths(events, crs_override=None):
    import rasterio
    stack, grid = [], None
    for name, path in events:
        with rasterio.open(path) as src:
            a = src.read(1, masked=True).astype(np.float32).filled(np.nan)
            if grid is None:
                grid = Grid(src.transform, src.crs, a.shape,
                            abs(src.transform.a * src.transform.e), src.nodata,
                            src.profile.copy())
            elif a.shape != grid.shape or src.transform != grid.transform:
                raise SystemExit(f"Grid of '{path}' differs from the first event grid.")
        a[a < 0] = np.nan
        stack.append(a)
        print(f"  read {name}: {path}")
    if crs_override:
        from rasterio.crs import CRS
        grid.crs = CRS.from_user_input(crs_override)
    return np.stack(stack), grid


def read_polygons(shp_path):
    """Read polygons from a shapefile (pyshp) into shapely geometries, plus .prj WKT."""
    import logging
    import shapefile
    import shapely
    from shapely.geometry import shape
    logging.getLogger("shapefile").setLevel(logging.ERROR)      # silence ring-orientation notices
    r = shapefile.Reader(shp_path)
    geoms = []
    for s in r.shapes():
        if s.shapeTypeName.upper().startswith("POLYGON") or s.shapeType in (5, 15, 25):
            geoms.append(shape(s.__geo_interface__))
    geoms = np.array(geoms, dtype=object)
    bad = ~shapely.is_valid(geoms)
    if bad.any():
        geoms[bad] = shapely.make_valid(geoms[bad])
    prj = os.path.splitext(shp_path)[0] + ".prj"
    wkt = open(prj).read() if os.path.exists(prj) else None
    return geoms, wkt


def check_crs(grid, wkt, label):
    if wkt is None or grid.crs is None:
        return
    from rasterio.crs import CRS
    try:
        if not CRS.from_wkt(wkt).equals(grid.crs) and CRS.from_wkt(wkt).to_epsg() != grid.crs.to_epsg():
            print(f"  WARNING: CRS of {label} differs from the depth grids; reproject it first.")
    except Exception:
        pass


def rasterise_mask(shp_path, grid):
    from rasterio.features import rasterize
    geoms, wkt = read_polygons(shp_path)
    check_crs(grid, wkt, shp_path)
    if grid.crs is None and wkt:
        from rasterio.crs import CRS
        grid.crs = CRS.from_wkt(wkt)
    m = rasterize([(g, 1) for g in geoms], out_shape=grid.shape, transform=grid.transform,
                  fill=0, all_touched=False, dtype="uint8")          # cell-centre rule
    return m.astype(bool)


def write_raster(path, arr, grid, dtype, nodata):
    import rasterio
    driver = "AAIGrid" if path.lower().endswith(".asc") else "GTiff"
    prof = dict(driver=driver, height=grid.shape[0], width=grid.shape[1], count=1,
                dtype=dtype, transform=grid.transform, nodata=nodata)
    if grid.crs is not None:
        prof["crs"] = grid.crs
    if driver == "GTiff":
        prof["compress"] = "lzw"
    with rasterio.open(path, "w", **prof) as dst:
        dst.write(arr.astype(dtype), 1)


def count_buildings(shp_path, grid, domain, classes):
    """Assign each footprint to the highest FSI class of the cells it intersects."""
    import shapely
    geoms, wkt = read_polygons(shp_path)
    check_crs(grid, wkt, shp_path)
    rr, cc = np.nonzero(domain)
    t = grid.transform
    x0, y0, dx, dy = t.c, t.f, t.a, t.e                   # dy < 0 for north-up grids
    xa, xb = x0 + cc * dx, x0 + (cc + 1) * dx
    ya, yb = y0 + rr * dy, y0 + (rr + 1) * dy
    boxes = shapely.box(np.minimum(xa, xb), np.minimum(ya, yb), np.maximum(xa, xb), np.maximum(ya, yb))
    tree = shapely.STRtree(geoms)
    cell_idx, bld_idx = tree.query(boxes, predicate="intersects")
    best = np.full(len(geoms), -1, dtype=np.int16)
    np.maximum.at(best, bld_idx, classes[rr, cc][cell_idx])
    return np.array([(best == k).sum() for k in range(len(CLASS_NAMES))]), int((best >= 0).sum())


# ----------------------------------------------------------------------------
# Robustness diagnostics
# ----------------------------------------------------------------------------
def robustness(depth_d, scores_d, names, edges, s_max, breaks, cell_area, shift=0.25):
    n = scores_d.shape[0]
    fsi = compute_fsi(scores_d, s_max)
    cls = classify(fsi, breaks)
    hvh = cls >= HIGH_CLASS_INDEX
    total = scores_d.sum(axis=0, dtype=np.int32)
    rows = []
    for j, name in enumerate(names):
        f_j = (total - scores_d[j]) / float(s_max * (n - 1))
        c_j = classify(f_j, breaks)
        h_j = c_j >= HIGH_CLASS_INDEX
        rows.append(dict(event_excluded=name,
                         jaccard_high_veryhigh=jaccard(h_j, hvh),
                         cells_changing_class_pct=100.0 * float((c_j != cls).mean()),
                         high_veryhigh_area_change_pct=100.0 * (h_j.sum() - hvh.sum()) / max(hvh.sum(), 1)))
    from scipy.stats import spearmanr
    freq = (np.nan_to_num(depth_d, nan=0.0) > edges[0]).mean(axis=0)
    rho = float(spearmanr(fsi, freq).correlation)
    thr = {}
    for sign, fac in (("minus", 1 - shift), ("plus", 1 + shift)):
        e = np.asarray(edges, float) * fac
        e[0] = edges[0]                                   # keep the no-flood threshold
        h_s = classify(compute_fsi(severity_scores(depth_d, e), s_max), breaks) >= HIGH_CLASS_INDEX
        thr[sign] = dict(area_change_pct=100.0 * (h_s.sum() - hvh.sum()) / max(hvh.sum(), 1),
                         original_zone_retained_pct=100.0 * (h_s & hvh).sum() / max(hvh.sum(), 1),
                         jaccard=jaccard(h_s, hvh))
    J = np.array([r["jaccard_high_veryhigh"] for r in rows])
    C = np.array([r["cells_changing_class_pct"] for r in rows])
    summary = dict(
        jaccard_min=float(np.nanmin(J)), jaccard_mean=float(np.nanmean(J)), jaccard_max=float(np.nanmax(J)),
        cells_changing_class_mean_pct=float(C.mean()), cells_changing_class_max_pct=float(C.max()),
        most_influential_event_jaccard=names[int(np.nanargmin(J))],
        most_influential_event_class_change=names[int(np.argmax(C))],
        spearman_rho_fsi_vs_frequency=rho,
        threshold_shift_fraction=shift,
        threshold_minus=thr["minus"], threshold_plus=thr["plus"])
    return rows, summary


# ----------------------------------------------------------------------------
# Map
# ----------------------------------------------------------------------------
def make_map(path, classes, domain, mask, grid, title=None):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    from matplotlib.colors import ListedColormap
    from matplotlib.patches import Patch
    t = grid.transform
    h, w = grid.shape
    ext = [t.c, t.c + w * t.a, t.f + h * t.e, t.f]
    rows = np.where(domain.any(axis=1))[0]
    cols = np.where(domain.any(axis=0))[0]
    fig, ax = plt.subplots(figsize=(10, 6))
    if mask is not None:
        ax.imshow(np.ma.masked_where(~mask, mask), cmap=ListedColormap(["#3DA5E0"]),
                  extent=ext, interpolation="nearest")
    ax.imshow(np.ma.masked_where(~domain, classes), cmap=ListedColormap(CLASS_COLOURS),
              vmin=0, vmax=4, extent=ext, interpolation="nearest")
    pad = 20
    ax.set_xlim(t.c + (cols.min() - pad) * t.a, t.c + (cols.max() + pad) * t.a)
    ax.set_ylim(t.f + (rows.max() + pad) * t.e, t.f + (rows.min() - pad) * t.e)
    ax.set_xlabel("Easting (m)"); ax.set_ylabel("Northing (m)")
    ax.ticklabel_format(style="plain", useOffset=False)
    labels = [f"{n} ({lo:g}–{hi:g})" for n, lo, hi in
              zip(CLASS_NAMES, [0] + DEFAULT_CLASS_BREAKS, DEFAULT_CLASS_BREAKS + [1])]
    handles = [Patch(color=c, label=l) for c, l in zip(CLASS_COLOURS, labels)]
    if mask is not None:
        handles.append(Patch(color="#3DA5E0", label="Excluded (mask)"))
    ax.legend(handles=handles, title="Flood Severity Index", loc="lower right", fontsize=8)
    if title:
        ax.set_title(title)
    fig.tight_layout()
    fig.savefig(path, dpi=300)
    plt.close(fig)


# ----------------------------------------------------------------------------
# Main
# ----------------------------------------------------------------------------
def parse_floats(s):
    return [float(v) for v in s.split(",")]


def main(argv=None):
    ap = argparse.ArgumentParser(description="Multi-event Flood Severity Index (FSI).",
                                 formatter_class=argparse.ArgumentDefaultsHelpFormatter)
    ap.add_argument("--events", nargs="+", required=True,
                    help="Maximum-depth grids, one per event: 'name=path', paths or glob patterns.")
    ap.add_argument("--mask", help="Polygon shapefile of areas excluded from the FSI (e.g. river and sea).")
    ap.add_argument("--buildings", help="Polygon shapefile of building footprints (optional).")
    ap.add_argument("--out", default="fsi_results", help="Output directory.")
    ap.add_argument("--depth-edges", type=parse_floats, default=DEFAULT_EDGES,
                    help="Depth-class boundaries (m); the first is the no-flood threshold.")
    ap.add_argument("--class-breaks", type=parse_floats, default=DEFAULT_CLASS_BREAKS,
                    help="FSI class boundaries.")
    ap.add_argument("--crs", help="CRS of the depth grids if not stored in the files, e.g. EPSG:32644.")
    ap.add_argument("--robustness", action="store_true", help="Compute robustness diagnostics.")
    ap.add_argument("--threshold-shift", type=float, default=0.25,
                    help="Relative shift of depth-class boundaries for the sensitivity test.")
    ap.add_argument("--map", action="store_true", help="Write a PNG map of the FSI classes.")
    ap.add_argument("--format", choices=["tif", "asc"], default="tif", help="Output raster format.")
    a = ap.parse_args(argv)

    t0 = time.time()
    os.makedirs(a.out, exist_ok=True)
    events = expand_events(a.events)
    if len(events) < 2:
        raise SystemExit("At least two events are required.")
    names = [n for n, _ in events]
    edges = sorted(a.depth_edges)
    s_max = len(edges)
    print(f"FSI v{__version__}: N = {len(events)} events, S_max = {s_max}")

    depth, grid = read_depths(events, a.crs)
    mask = rasterise_mask(a.mask, grid) if a.mask else None
    wet = np.nan_to_num(depth, nan=0.0) > edges[0]
    domain = wet.any(axis=0)
    if mask is not None:
        domain &= ~mask

    scores = severity_scores(depth, edges)
    fsi = compute_fsi(scores, s_max)
    classes = classify(fsi, a.class_breaks)
    ca = grid.cell_area

    # rasters
    ext = a.format
    write_raster(os.path.join(a.out, f"FSI_values.{ext}"), np.where(domain, fsi, -9999.0), grid, "float32", -9999.0)
    write_raster(os.path.join(a.out, f"FSI_classes.{ext}"), np.where(domain, classes + 1, 0), grid, "uint8", 0)
    n_wet = wet.sum(axis=0)
    write_raster(os.path.join(a.out, f"events_inundated.{ext}"), np.where(domain, n_wet, 0), grid, "uint8", 0)

    # class summary
    c_dom = classes[domain]
    area_total = domain.sum() * ca
    bld, bld_total = (None, None)
    if a.buildings:
        print("  counting buildings ...")
        bld, bld_total = count_buildings(a.buildings, grid, domain, classes)
    breaks = [0.0] + list(a.class_breaks) + [1.0]
    rows = []
    for k, name in enumerate(CLASS_NAMES):
        area = (c_dom == k).sum() * ca
        row = dict(fsi_class=name, fsi_range=f"{breaks[k]:g}-{breaks[k+1]:g}",
                   area_km2=round(area / 1e6, 3), area_pct=round(100 * area / area_total, 2))
        if bld is not None:
            row["buildings"] = int(bld[k])
        rows.append(row)
    total_row = dict(fsi_class="Total", fsi_range="-", area_km2=round(area_total / 1e6, 3), area_pct=100.0)
    if bld is not None:
        total_row["buildings"] = bld_total
    rows.append(total_row)
    with open(os.path.join(a.out, "fsi_class_summary.csv"), "w", newline="") as f:
        wtr = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        wtr.writeheader(); wtr.writerows(rows)

    # per-event inundated area (quick consistency check with other analyses)
    ev_rows = [dict(event=nm, inundated_area_km2=round(float((wet[j] & (~mask if mask is not None else True)).sum() * ca / 1e6), 3))
               for j, nm in enumerate(names)]
    with open(os.path.join(a.out, "event_inundated_area.csv"), "w", newline="") as f:
        wtr = csv.DictWriter(f, fieldnames=["event", "inundated_area_km2"])
        wtr.writeheader(); wtr.writerows(ev_rows)

    log = dict(version=__version__, n_events=len(events), events=dict(events), s_max=s_max,
               depth_edges_m=edges, class_breaks=list(a.class_breaks), mask=a.mask, buildings=a.buildings,
               cell_area_m2=ca, evaluated_area_km2=area_total / 1e6,
               python=sys.version.split()[0], platform=platform.platform())

    if a.robustness:
        print("  robustness diagnostics ...")
        loo, summ = robustness(depth[:, domain], scores[:, domain], names, edges, s_max,
                               a.class_breaks, ca, a.threshold_shift)
        with open(os.path.join(a.out, "robustness_leave_one_out.csv"), "w", newline="") as f:
            wtr = csv.DictWriter(f, fieldnames=list(loo[0].keys()))
            wtr.writeheader(); wtr.writerows(loo)
        with open(os.path.join(a.out, "robustness_summary.json"), "w") as f:
            json.dump(summ, f, indent=2)
        log["robustness"] = summ

    if a.map:
        make_map(os.path.join(a.out, "FSI_map.png"), classes, domain, mask, grid)

    with open(os.path.join(a.out, "run_log.json"), "w") as f:
        json.dump(log, f, indent=2, default=str)

    # console report
    print("\nFSI class summary")
    for r in rows:
        extra = f"  buildings {r['buildings']:>7,}" if "buildings" in r else ""
        print(f"  {r['fsi_class']:<10} {r['fsi_range']:<8} {r['area_km2']:8.2f} km2 {r['area_pct']:6.1f} %{extra}")
    if a.robustness:
        s = log["robustness"]
        print("\nRobustness")
        print(f"  Jaccard (min / mean / max): {s['jaccard_min']:.2f} / {s['jaccard_mean']:.2f} / {s['jaccard_max']:.2f}")
        print(f"  Cells changing class (mean / max): {s['cells_changing_class_mean_pct']:.1f} / {s['cells_changing_class_max_pct']:.1f} %")
        print(f"  Most influential event: {s['most_influential_event_jaccard']} (Jaccard), "
              f"{s['most_influential_event_class_change']} (class change)")
        print(f"  Spearman rho FSI vs frequency: {s['spearman_rho_fsi_vs_frequency']:.2f}")
        print(f"  Depth thresholds -/+{100*a.threshold_shift:g}%: "
              f"{s['threshold_minus']['area_change_pct']:+.1f} / {s['threshold_plus']['area_change_pct']:+.1f} % (high + very high area)")
    print(f"\nOutputs written to {os.path.abspath(a.out)}  ({time.time()-t0:.0f} s)")


if __name__ == "__main__":
    main()
