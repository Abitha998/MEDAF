"""Minimal checks of the FSI computations (no input files needed)."""
import numpy as np
from fsi import severity_scores, compute_fsi, classify, jaccard

d = np.array([0.0, 0.1, 0.1001, 0.25, 0.26, 0.5, 1.0, 2.0, 3.0, 3.5, np.nan])
assert severity_scores(d).tolist() == [0, 0, 1, 1, 2, 2, 3, 4, 5, 6, 0]

# a cell deeper than 3 m in every event -> FSI = 1 for any N
for n in (2, 5, 8, 20):
    s = severity_scores(np.full((n, 1), 4.0))
    assert compute_fsi(s, 6)[0] == 1.0

# worked example: scores 4,5,3,6,4,2,6,5 -> 35/48 = 0.729 -> high
s = np.array([4, 5, 3, 6, 4, 2, 6, 5], dtype=np.uint8)[:, None]
f = compute_fsi(s, 6)[0]
assert abs(f - 35 / 48) < 1e-12 and classify(np.array([f]))[0] == 3

# class boundaries include their lower bound
assert classify(np.array([0.0, 0.2, 0.4, 0.6, 0.8, 1.0])).tolist() == [0, 1, 2, 3, 4, 4]
assert jaccard(np.array([1, 1, 0], bool), np.array([1, 0, 0], bool)) == 0.5
print("all tests passed")
